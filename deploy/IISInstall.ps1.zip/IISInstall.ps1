Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
	# Copy the website content
    Script DeployWebPackage01
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp3.zip" 
        $WebClient.DownloadFile("https://vmsscodestg01.blob.core.windows.net/code/VanilaWebApp.zip",$destination)
		MD C:\Web3
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp3.zip" -DestinationPath:"C:\Web3"
		New-WebAppPool -Name:Test3
        New-Website -Name:Test2 -Port:83 -HostHeader:www.test3.com -PhysicalPath:c:\web3 -ApplicationPool:Test3
        }
	}
	
	# Copy the website content
    Script DeployWebPackage02
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp4.zip" 
        $WebClient.DownloadFile($using:WebDeployPackagePath,$destination)
		MD C:\Web4
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp4.zip" -DestinationPath:"C:\Web4"
		New-WebAppPool -Name:Test4
        New-Website -Name:Test4 -Port:84 -HostHeader:www.test4.com -PhysicalPath:c:\web4 -ApplicationPool:Test4
        }
	}
  }
}