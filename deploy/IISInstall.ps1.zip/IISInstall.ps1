Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
	# Copy the website content
    Script DeployWebPackage
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
        New-Website -Name:Test -Port:81 -HostHeader:www.tet.com -PhysicalPath:c:\web
        }
	}
  }
}