Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
	# Copy the website content
        File WebContent
        {
            Ensure          = "Present"
            SourcePath      = "C:\WindowsAzure\WebApplication1\"
            DestinationPath = "C:\Web\"
            Recurse         = $true
            Type            = "Directory"
            DependsOn       = "[WindowsFeature]AspNet45"
        }

    Script DeployWebPackage
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
        New-Website -Name:Test -Port:81 -HostHeader:www.tet.com -PhysicalPath:c:\web
        }
	}
  }
}