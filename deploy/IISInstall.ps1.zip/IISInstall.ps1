Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
  
  
	# Copy the website content
    Script DeployWebPackage
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp.zip" 
        $WebClient.DownloadFile("https://vmsscodestg01.blob.core.windows.net/code/VanilaWebApp.zip",$destination)
		MD C:\Web1
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp.zip" -DestinationPath:"C:\Web1"
		New-WebAppPool -Name:Test1
        New-Website -Name:Test1 -Port:82 -HostHeader:www.test1.com -PhysicalPath:c:\web1 -ApplicationPool:Test1
        }
	}
  }
}