Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
	# Copy the website content
    Script DeployWebPackage01
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp5.zip" 
        $WebClient.DownloadFile("https://vmsscodestg01.blob.core.windows.net/code/VanilaWebApp.zip",$destination)
		MD C:\Web5
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp5.zip" -DestinationPath:"C:\Web5"
		New-WebAppPool -Name:Test5
        New-Website -Name:Test5 -Port:85 -HostHeader:www.test5.com -PhysicalPath:c:\web5 -ApplicationPool:Test5
        }
	}
	
	# Copy the website content
    Script DeployWebPackage02
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp6.zip" 
        $WebClient.DownloadFile($using:WebDeployPackagePath,$destination)
		MD C:\Web6
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp6.zip" -DestinationPath:"C:\Web6"
		New-WebAppPool -Name:Test6
        New-Website -Name:Test6 -Port:86 -HostHeader:www.test6.com -PhysicalPath:c:\web6 -ApplicationPool:Test6
        }
	}
  }
}