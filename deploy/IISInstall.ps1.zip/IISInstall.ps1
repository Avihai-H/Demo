Configuration InstallIIS
# Configuration Main
{

Param ( [string] $nodeName, $WebDeployPackagePath)

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
  
  
	# Copy the website content
    Script DeployWebPackage
	{
		GetScript = {
            @{
                Result = ""
            }
        }
        TestScript = {
            $false
        }
        SetScript ={
		$WebClient = New-Object -TypeName System.Net.WebClient
		$Destination= "C:\WindowsAzure\VanilaWebApp.zip" 
        $WebClient.DownloadFile("https://vmsscodestg01.blob.core.windows.net/code/VanilaWebApp.zip",$destination)
		MD C:\Web2
		Expand-Archive -Path:"C:\WindowsAzure\VanilaWebApp.zip" -DestinationPath:"C:\Web2"
		New-WebAppPool -Name:Test2
        New-Website -Name:Test2 -Port:81 -HostHeader:www.test2.com -PhysicalPath:c:\web2 -ApplicationPool:Test2
        }
	}
  }
}